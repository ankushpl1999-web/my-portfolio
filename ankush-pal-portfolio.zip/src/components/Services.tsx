import { motion } from "motion/react";
import { TrendingUp, BarChart3, Briefcase, Search } from "lucide-react";

const services = [
  {
    icon: BarChart3,
    title: "Financial Analysis",
    description: "In-depth analysis of financial statements and market trends to support data-driven investment decisions.",
  },
  {
    icon: TrendingUp,
    title: "Market Research",
    description: "Comprehensive research on industry dynamics, competitor performance, and emerging market opportunities.",
  },
  {
    icon: Briefcase,
    title: "Portfolio Management",
    description: "Strategic planning and management of assets to optimize returns while mitigating financial risks.",
  },
  {
    icon: Search,
    title: "Investment Strategy",
    description: "Developing tailored investment strategies based on fundamental analysis and technical market indicators.",
  },
];

export default function Services() {
  return (
    <section id="services" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl font-bold tracking-tight mb-4"
          >
            Services I Offer
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-muted"
          >
            I help businesses grow by designing and developing high-quality digital products.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -10 }}
              className="p-8 rounded-3xl bg-background border border-gray-100 hover:border-accent/20 hover:shadow-xl hover:shadow-accent/5 transition-all duration-300"
            >
              <div className="w-14 h-14 bg-accent/10 rounded-2xl flex items-center justify-center text-accent mb-6">
                <service.icon size={28} />
              </div>
              <h3 className="text-xl font-bold mb-4">{service.title}</h3>
              <p className="text-muted text-sm leading-relaxed">
                {service.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

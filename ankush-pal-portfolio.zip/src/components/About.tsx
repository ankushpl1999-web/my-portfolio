import { motion } from "motion/react";

const skills = [
  { name: "Financial Analysis", level: 90 },
  { name: "Market Research", level: 85 },
  { name: "Investment Management", level: 80 },
  { name: "Bloomberg Terminal", level: 75 },
  { name: "MS Office (Excel)", level: 95 },
];

export default function About() {
  return (
    <section id="about" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl font-bold mb-8 tracking-tight">
              A <span className="text-accent italic">finance-driven</span> professional in the making.
            </h2>
            <p className="text-lg text-muted mb-6 leading-relaxed">
              I am Ankush Pal, a PGDM Finance student at ISBR Business School, Bangalore. 
              My focus is on understanding the complexities of global financial markets 
              and developing the analytical skills necessary for strategic decision-making.
            </p>
            <p className="text-lg text-muted mb-8 leading-relaxed">
              With a background in Business Administration and practical experience in 
              digital marketing, I bring a unique, multi-disciplinary perspective to 
              financial analysis and management. I am committed to continuous learning 
              and professional excellence.
            </p>
            
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-accent" />
                <span className="text-ink font-medium">PGDM Finance (2025-2027) - ISBR Bangalore</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-accent" />
                <span className="text-ink font-medium">BBA (2018-2021) - IMS Ghaziabad</span>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-background p-10 rounded-3xl"
          >
            <h3 className="text-xl font-bold mb-8">My Expertise</h3>
            <div className="space-y-6">
              {skills.map((skill, i) => (
                <div key={skill.name}>
                  <div className="flex justify-between mb-2">
                    <span className="font-medium text-ink">{skill.name}</span>
                    <span className="text-accent font-bold">{skill.level}%</span>
                  </div>
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: `${skill.level}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 1, delay: 0.5 + i * 0.1 }}
                      className="h-full bg-accent rounded-full"
                    />
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

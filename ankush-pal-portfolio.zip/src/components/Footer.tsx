import { Dribbble, Twitter, Instagram, Github, ArrowUp } from "lucide-react";
import { motion } from "motion/react";

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="py-12 border-t border-gray-100">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex flex-col items-center md:items-start gap-4">
            <a href="#" className="text-2xl font-bold tracking-tighter">
              Ankush<span className="text-accent">.</span>
            </a>
            <p className="text-muted text-sm">
              © {new Date().getFullYear()} Ankush Pal. All rights reserved.
            </p>
          </div>

          <div className="flex gap-6">
            {[Dribbble, Twitter, Instagram, Github].map((Icon, i) => (
              <motion.a
                key={i}
                href="#"
                whileHover={{ y: -3, color: "var(--color-accent)" }}
                className="text-muted transition-colors"
              >
                <Icon size={20} />
              </motion.a>
            ))}
          </div>

          <motion.button
            onClick={scrollToTop}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="w-12 h-12 rounded-full bg-background border border-gray-200 flex items-center justify-center text-muted hover:text-accent hover:border-accent transition-all"
          >
            <ArrowUp size={20} />
          </motion.button>
        </div>
      </div>
    </footer>
  );
}

import { motion } from "motion/react";
import { ExternalLink, ArrowUpRight } from "lucide-react";

const experiences = [
  {
    title: "Bloomberg Market Concepts (BMC)",
    company: "Bloomberg for Education",
    period: "Certification",
    image: "https://images.unsplash.com/photo-1535320903710-d993d3d77d29?auto=format&fit=crop&q=80&w=800",
    description: "Completed the Bloomberg Market Concepts course, gaining proficiency in economic indicators, currencies, fixed income, and equities.",
  },
  {
    title: "Financial Education & Financial Markets (FE-FM)",
    company: "ISBR & Stockathon Academy",
    period: "Dec'25 - Jan'26",
    image: "https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?auto=format&fit=crop&q=80&w=800",
    description: "Certified programme covering fundamental and technical aspects of financial markets and investment strategies.",
  },
  {
    title: "Digital Marketing Intern",
    company: "Fillip Technologies Pvt Ltd",
    period: "Aug 2020 – Oct 2020",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800",
    description: "Gained practical experience in SEO, backlinking, and digital strategy, providing a strong foundation in market dynamics.",
  },
];

export default function Works() {
  return (
    <section id="works" className="py-24">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold tracking-tight mb-4">Experience & Certifications</h2>
            <p className="text-muted max-w-md">
              A summary of my professional internships and industry-recognized certifications.
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {experiences.map((exp, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group cursor-pointer"
            >
              <div className="relative aspect-[16/10] rounded-3xl overflow-hidden mb-6 bg-gray-100">
                <img
                  src={exp.image}
                  alt={exp.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div>
                <span className="text-xs font-bold text-accent uppercase tracking-widest mb-2 block">
                  {exp.period}
                </span>
                <h3 className="text-xl font-bold mb-2 group-hover:text-accent transition-colors">
                  {exp.title}
                </h3>
                <p className="text-ink font-medium text-sm mb-2">{exp.company}</p>
                <p className="text-muted text-sm">
                  {exp.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
